<?php
require_once 'config.php';
include _ROOT_PATH.'/app/calc_view.php';
?>